require("core.keymaps")
require('core.plugin-config')
require("core.plugins")

