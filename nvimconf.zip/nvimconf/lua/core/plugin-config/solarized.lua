vim.o.termguicolors = true
vim.cmd [[ colorscheme solarized ]]
