require('core.plugin-config.solarized')
require('core.plugin-config.nvim-treesitter')
require('core.plugin-config.nvim-tree')
